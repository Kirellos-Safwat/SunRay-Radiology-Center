create function getplayerscoresum(player_id integer) returns integer
    language plpgsql
as
$$
DECLARE
  total_score INT;
BEGIN
  SELECT COALESCE(SUM(score), 0)
  INTO total_score
  FROM level_details
  WHERE P_ID = GetPlayerScoreSum.player_id;

  RETURN total_score;
END;
$$;

alter function getplayerscoresum(integer) owner to postgres;

