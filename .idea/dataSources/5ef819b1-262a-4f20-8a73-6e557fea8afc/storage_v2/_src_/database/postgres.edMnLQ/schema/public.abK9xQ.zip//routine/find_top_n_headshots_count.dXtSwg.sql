create function find_top_n_headshots_count(n integer)
    returns TABLE(dev_id integer, headshots_count integer, difficulty text)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY
  SELECT ranked_results.dev_id, ranked_results.headshots_count, ranked_results.difficulty
  FROM (
    SELECT level_details.dev_id, level_details.headshots_count, level_details.difficulty,
           ROW_NUMBER() OVER (PARTITION BY level_details.dev_id ORDER BY level_details.headshots_count) AS rank
    FROM level_details
  ) AS ranked_results
  WHERE ranked_results.rank <= n
  ORDER BY ranked_results.dev_id, ranked_results.rank;
END;
$$;

alter function find_top_n_headshots_count(integer) owner to postgres;

