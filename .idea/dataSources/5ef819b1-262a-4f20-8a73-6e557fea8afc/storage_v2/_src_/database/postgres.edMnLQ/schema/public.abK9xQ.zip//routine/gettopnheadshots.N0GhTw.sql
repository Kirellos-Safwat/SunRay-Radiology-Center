create procedure gettopnheadshots(IN n integer, OUT result json)
    language plpgsql
as
$$
BEGIN
  SELECT json_agg(json_build_object(
    'dev_id', dev_id,
    'difficulty', difficulty,
    'headshots_count', headshots_count,
    'rank', rank
  ))
  INTO result
  FROM (
    SELECT dev_id, difficulty, headshots_count,
           ROW_NUMBER() OVER (PARTITION BY dev_id ORDER BY headshots_count ASC) AS rank
    FROM level_details
  ) AS subquery
  WHERE rank <= n;
END;
$$;

alter procedure gettopnheadshots(integer, out json) owner to postgres;

